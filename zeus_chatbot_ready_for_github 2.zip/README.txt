
# Zeus - Chatbot Pessoal

Este é o Zeus, uma IA que responde perguntas sobre treino, dieta e administração com um estilo direto. Rodando no seu navegador com Streamlit.

## Como usar (Google Colab ou local)
1. Instale as dependências:
```bash
pip install streamlit transformers
```

2. Rode o app:
```bash
streamlit run zeus_app.py
```

3. Abra no navegador o link que aparecer (geralmente http://localhost:8501)

Você pode perguntar coisas como:
- Me dá uma dieta de 2.300 kcal pra ganhar massa
- Como treinar ombro 2x na semana?
- Faz um resumo sobre os 4 Ps do marketing

**Zeus responde tudo, sem enrolar.**
